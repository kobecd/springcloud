package com.arc.mybatisplus.config;

/**
 * @author: yechao
 * @date: 2018/12/25 23:50
 * @description:
 */
public class MybatisConfig {
    //https://gitee.com/baomidou/mybatisplus-spring-boot.git
}
